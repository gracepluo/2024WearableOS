package io.ostendorf.heartratetoweb

enum class RunningState {
    RUNNING,
    STOPPED
}
